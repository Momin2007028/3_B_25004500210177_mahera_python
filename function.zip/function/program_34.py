# Function Program 34

nums = [1, 2, 3, 4, 5]
result = list(map(lambda x: x * x, nums))
print(result)
